package esame2022_giugno30_jobOffers;

public class Application {
	String candidate;
	String position;
	public Application(String candidate, String position) {
		this.candidate = candidate;
		this.position = position;
	}
	public String getCandidate() {
		return candidate;
	}
	public String getPosition() {
		return position;
	}
	
}
