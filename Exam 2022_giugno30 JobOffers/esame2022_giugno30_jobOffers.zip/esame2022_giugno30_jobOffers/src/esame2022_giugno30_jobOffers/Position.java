package esame2022_giugno30_jobOffers;

import java.util.*;

public class Position {
	String position;
	TreeMap<String,Integer> skillLevelMap=null;
	
	public Position(String position, TreeMap<String, Integer> skillLevelMap) {//costruttore
		super();
		this.position = position;
		this.skillLevelMap = skillLevelMap;
	}
	
	int getAverageLevel() {
		return skillLevelMap.values().stream().mapToInt(v->v).sum()/skillLevelMap.size();
	}
}
