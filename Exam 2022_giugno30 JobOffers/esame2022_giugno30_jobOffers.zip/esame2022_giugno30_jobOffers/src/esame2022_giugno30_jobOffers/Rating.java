package esame2022_giugno30_jobOffers;
import java.util.*;


public class Rating {
	String consultant;
		String candidate;
		TreeMap<String,Integer> skillRatings=null;
		
		public Rating(String consultant, String candidate, TreeMap<String, Integer> skillRatings) {
			super();
			this.consultant = consultant;
			this.candidate = candidate;
			this.skillRatings = skillRatings;
		}
		
		int getAverageRating() {
			return skillRatings.values().stream()
					.mapToInt(v->v).sum()/skillRatings.size();
			}
}
