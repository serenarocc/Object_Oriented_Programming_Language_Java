package esame2022_giugno30_jobOffers;
import java.util.*;
import static java.util.stream.Collectors.*;
import static java.util.Comparator.*;

public class JobOffers {
	TreeSet<String> skillsColl=new TreeSet<>();// xke treeSet ????????? xke toglie le duplicazioni, e ordina gli elementi
	TreeMap<String,Position> positionsColl=new TreeMap<>();
	TreeMap<String,Candidate> candidatesColl=new TreeMap<>();
	List <Application> applications=new ArrayList<>();
	TreeMap<String,Consultant> consultantsColl=new TreeMap<>();

	//R1
// inserisce alcune capacità, come ad esempio java, python, ecc. La capacità duplicate sono ignorate. 
//Il metodo restituisce il numero di capacità totali inserite finora.
		public int addSkills (String... skills) {
			for(String skill:skills) {
				skillsColl.add(skill);
			}
			return skillsColl.size();
		}
/*inserisce un posto di lavoro, come ad esempio juniorProgrammer, con le capacità richieste
 *e il livello richiesto di conoscenza (si vedano gli esempi in TestApp). 
 *Una capacità è seguita da un ":" e dal livello di conoscenza, compreso tra 4 e 8, inclusi.
 *Il metodo lancia un'eccezione se: il posto è già stato inserito, una o più delle capacità 
 *non sono state definite oppure se il livello non è tra 4 e 8. Il risultato è la media dei livelli.*/		
		public int addPosition (String position, String... skillLevels) throws JOException {
			if(positionsColl.containsKey(position)) throw new JOException("posizione duplicata");
			
			TreeMap<String,Integer>skillLevelMap=new TreeMap<>();//treeMap che contiene la capacita' con il corrispettivo livello
			for(String skillLevel:skillLevels) {//scorro con un for la lista skillLevels
				String[] elements=skillLevel.split(":"); //divido ogni nodo della lista separandolo in base alla :
				String skill=elements[0];//la prima parte della separazione e' dentro elements[0]
				int level=Integer.parseInt(elements[1]);//la seconda parte della separazione e' dentro elements[1]
				
				if(!skillsColl.contains(skill))throw new JOException("skill non trovata");
				if(level<4||level>8)throw new JOException("livello sbagliato");
				skillLevelMap.put(skill, level);//aggiungo capacita' e livello della capacita'
			}
			
			Position p=new Position(position,skillLevelMap);
			positionsColl.put(position, p);
			return p.getAverageLevel();
		}
		
	//R2	
/* inserisce il nome di un candidato con la sua lista di capacità. Il meodo lancia
 * un'eccezione se il candidato è già stato aggiunto o se una capacità non è stata definita. 
 * Il risultato è il numero di capacità.
 * */
public int addCandidate (String name, String... skills) throws JOException {//???????????????
		List<String> skillsList=new ArrayList<String>(Arrays.asList(skills));//lista di capacità
		//CREA UNA LIST DA UN ARRAY ( skills e' il nome dell array).  -->skillsList e' il nome della lista
		//CREA UNA COPIA FATTA A LISTA DELL'ARRAY ORIGINALE-> POSSO MANIPOLARE LA LISTA SENZA ANDARE A MODIFICARE L'ARRAY ORIGINALE
		
		if(candidatesColl.containsKey(name)) throw new JOException("duplicato candidate"+name);
		if(! skillsColl.containsAll(skillsList)) throw new JOException ("unknown skills in addCandidate " + name);//eccezione se se una capacità non è stata definita.
		
		Candidate c=new Candidate(name,new TreeSet<String> (skillsList) );//xke tree set?????
		candidatesColl.put(name, c);
		return skills.length;//lunghezza dell'array fornito come parametro
	}


/*permette ad un candidato di candidarsi per uno o più posti di lavoro. 
 * Il metodo lancia un'eccesione se:
 * - il candidato non è stato definito,
 * - non tutti i posti di lavoro sono stati definiti, 
 * - il candidato non ha le capacità richieste per i posti di lavoro. 
 * Il metodo restituisce una lista di candidature; 
 * una candidatura è una stringa che contiene il nome del candidato seguito da ":" e dal nome di un posto di
 * lavoro. Le stringhe sono ordinate per candidato e posto.*/
		public List<String> addApplications (String candidate, String... positions) throws JOException { //?????????????????
			if(!candidatesColl.containsKey(candidate)) throw new JOException(" il candidato non è stato definito"); //  il candidato non è stato definito
			
			Candidate c=candidatesColl.get(candidate);
			List<String> positionsList=new ArrayList<String>(Arrays.asList(positions));
			if(!positionsColl.keySet().containsAll(positionsList)) {
				throw new JOException("posizione sconosciuta");//non tutti i posti di lavoro sono stati definiti
			}
			for(String posizione:positions) {
				if(!c.skills.containsAll(positionsColl.get(posizione).skillLevelMap.keySet())) {//???
					throw new JOException("candiadto non ha tutte le capacita' richieste per il posto di lavoro"+candidate+" "+ c.skills+ " "+ positionsColl.get(posizione).skillLevelMap.keySet());
				}
			}
			for (String position: positions) {
				applications.add (new Application(candidate, position));
			}
			List<String> list = new ArrayList<>();
			for (String position: positions) {
				list.add(candidate + ":" + position);
			}
			Collections.sort(list);
			return list;
		} 
		
		
		
		
		
		
		
		
/* restituisce una mappa le cui chiavi sono i nomi dei posti di lavoro in ordine alfabetico;
 *  i valori sono le liste ordinate dei candidati che si sono candidati al posto. 
 *  I posti di lavoro se non hanno candidati non devono comparire.*/		
public TreeMap<String, List<String>> getCandidatesForPositions() {
	TreeMap<String, List<String>> map= applications.stream()
										.sorted(comparing(Application::getCandidate))//?????? 
										.collect(groupingBy(Application::getPosition, //restituisce una mappa le cui chiavi sono i nomi dei posti di lavoro in ordine alfabetico
															TreeMap::new,
															mapping(Application::getCandidate,//  i valori sono le liste ordinate dei candidati che si sono candidati al posto. 
																	toList())));
	
	return map;
}
		
		
//R3
/*inserisce il nome di un consulente con le relative capacità. 
 * Il metodo lancia un'eccezione se:
 *  - il consulente è già stato definito o 
 *  - se una capacità non è stata definita. Il risultato è il numero di capacità.
 * */
	public int addConsultant (String name, String... skills) throws JOException {
		List<String> skillsList=new ArrayList<String>(Arrays.asList(skills));
		if(consultantsColl.containsKey(name)) throw new JOException("consulente duplicato"+name);// il consulente è già stato definito 
		if(!skillsColl.containsAll(skillsList))throw new JOException("skills sconosciuta");//se una capacità non è stata definita.
		
		Consultant c=new Consultant(name, new TreeSet<>(skillsList));
		consultantsColl.put(name,c);
		return skills.length;
	}
	
	
/*permette a un consulente di assegnare un punteggio a ciascuna della capacità indicate
 * da un candidato.
 * Un esempio di punteggio è il seguente: ["java:8", "databases:6"]. 
 * Ogni stringa è formata dalla capacità seguita da due-punti e il punteggio.
 * Il punteggio è tra 4 e 10 inclusi. 
 * Il metodo lancia un'eccezione se:
 * -  il consulente o il candidato non sono stati definite, 
 * - se le capacità del consulente non includono tutte quelle dichiarate dal candidato, 
 * - o se ci sono dei punteggi fuori dai limiti. 
 * Il metodo restituisce la media dei punteggi.
 * */
	public Integer addRatings (String consultant, String candidate, String... skillRatings)  throws JOException {
		
		if(!candidatesColl.containsKey(candidate)) throw new JOException("candidato non definito");//il candidato  non sono stati definite, 
		if(!consultantsColl.containsKey(consultant)) throw new JOException("consulente non definito");//il consulente  non sono stati definite, 
		
		Candidate candidateObj = candidatesColl.get(candidate);
		Consultant consultantObj = consultantsColl.get(consultant);
		
		if (! consultantObj.skills.containsAll(candidateObj.skills)) {
			throw new JOException ("capacita consulente non include capacita' cndidato");//se le capacità del consulente non includono tutte quelle dichiarate dal candidato
		}
		
		TreeMap<String, Integer> skillsRatingsMap = new TreeMap<>();//variabile temporanea: abilita:punteggio del candidato passato come parametro in quel momento
		
		for(String punteggio: skillRatings) {
			String[] elements=punteggio.split(":");
			String skill=elements[0];
			int rating=Integer.parseInt(elements[1]);
			if(rating<4 || rating >10) throw new JOException("rating sbagliato");
			
			skillsRatingsMap.put(skill,rating);
		}
		//verifica se le competenze valutate corrispondono a quelle del candidato
		if (! skillsRatingsMap.keySet().containsAll(candidateObj.skills)) throw new JOException ("some skills not rated");//???????

		candidateObj.skillsRatingsMap=skillsRatingsMap;//??? copia/salvataggio della mappa del singolo candidato
		return candidateObj.getAverageRating();//???
	}
	
//R4
	
/* scarta le candidature dei candidati non ammissibili. Un candidato è considerato
 * non ammissibile se una o più delle sue capacità hanno un punteggio inferiore 
 * al livello richiesto per il posto di lavoro. I punteggi sono quelli precedentemente 
 * inseriti tramite il metodo addRatings(). 
 * Il metodo restituisce la lista delle candidature scartate, 
 * le candidature sono espresse da stringhe con il nome del candidato seguito 
 * da ":" ed il nome del posto. La lista è ordinata alfabeticamente per candidati e posizioni.
 *  La lista può essere vuota.
 * */
	public List<String> discardApplications() {//???????????????????
		List<String> discardedApps = new ArrayList<>();
		TreeMap<String, Integer> skillsRatingsMap;
		
		for (Application app: applications) { //candidate position
			//TreeMap<String, Integer> skillLevelMap = positionsColl.get(app.position).skillLevelMap;
			Candidate candidateObj = candidatesColl.get(app.candidate);
			skillsRatingsMap = candidateObj.skillsRatingsMap;
			
			if (skillsRatingsMap == null) {
				//System.out.println ("no ratings for candidate " + app.candidate);
				discardedApps.add(app.candidate + ":" + app.position);
			}
			else {
				//System.out.println ("ratings for candidate " + app.candidate + " " + skillsRatingsMap);
				Position p = positionsColl.get(app.position);
				for (String skillNeeded: p.skillLevelMap.keySet()) {//keySet mi tira fuori l'elenco delle chiavi
					int level = p.skillLevelMap.get(skillNeeded);
					int rate = skillsRatingsMap.get(skillNeeded);
					//System.out.println(app.candidate + " " + skillNeeded + " rating and level " + rate + " " + level);

					if (rate < level) {
						discardedApps.add(app.candidate + ":" + app.position);
					}
				}
			}
			Collections.sort(discardedApps);//La lista è ordinata alfabeticamente per candidati e posizioni. A parita' di candidato poi ordino per : posizione
			//
			//System.out.println ("discardedApps " + discardedApps);
			return discardedApps;
		
	}
}
	
/*seleziona le candidature ammissibili per un posto. I candidati devono essersi candidati
 * alla posizione, le loro capacità devono includere quelle del posto, e inoltre 
 * i punteggi delle capacità (forniti dai consulenti) non devono essere inferiori 
 * ai livelli definiti col metodo addPosition. Il risultato è una lista di candidati 
 * ammissibili in ordine alfabetico, la lista può essere vuota.
 * */ 
	public List<String> getEligibleCandidates(String position) {//?????????????
		List<String> candidateWinners=new ArrayList<>();
		Position p=positionsColl.get(position);//mi serve p xke devo fare il confronto per : I candidati devono essersi candidati alla posizione
		for(Application app: applications) {
			
			if(app.getPosition().equals(position)) {// I candidati devono essersi candidati alla posizione
				String candidate = app.getCandidate();//prendo candidato che ha fatto apply per quella posizione
				Candidate candidateObj = candidatesColl.get(candidate);//del candidato prendo i valori
				int negative = 0;
				TreeMap<String, Integer> skillsRatingsMap = candidateObj.skillsRatingsMap; 
				if (skillsRatingsMap == null) negative -= 1;
				else {
					for (String skillNeeded: p.skillLevelMap.keySet()) {
						int level = p.skillLevelMap.get(skillNeeded);
						int rate = skillsRatingsMap.get(skillNeeded);
						if (rate < level) negative -= 1;
					}
				}
				if (negative == 0) candidateWinners.add(candidate);
			}
		}
		
		Collections.sort(candidateWinners);
		return candidateWinners;
	}
}
