package esame2022_giugno30_jobOffers;

import java.util.*;

public class Candidate {
	String name;
	Set<String> skills=new TreeSet<>();//xke si usa un treeSet ?????
	//treeSet-->non ha duplicazione di elementi, gli oggetti sono ordinati
	
	public Candidate(String name, Set<String> skills) {
		super();
		this.name = name;
		this.skills = skills;
	}
	
	TreeMap<String, Integer> skillsRatingsMap;
	
	int getAverageRating () {
		return skillsRatingsMap.values().stream()
				.mapToInt(v -> v).sum() / skillsRatingsMap.size();
	}
	
	TreeMap<String, Integer> getSkillsRatingsMap() {
		return skillsRatingsMap;
	}

}
