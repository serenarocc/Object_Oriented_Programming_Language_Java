package esame2022_giugno30_jobOffers;

import java.util.*;

public class Consultant {
	String name;
	Set<String> skills=null;//xke set???
	public Consultant(String name, Set<String> skills) {
		super();
		this.name = name;
		this.skills = skills;
	}
}
