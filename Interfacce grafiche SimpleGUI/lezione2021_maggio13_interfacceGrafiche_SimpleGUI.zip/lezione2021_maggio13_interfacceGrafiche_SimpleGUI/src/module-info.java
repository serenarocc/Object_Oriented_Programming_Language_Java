/**
 * 
 */
/**
 * @author seren
 *
 */
module lezione2021_maggio13_interfacceGrafiche_SimpleGUI {
	requires java.desktop;
}