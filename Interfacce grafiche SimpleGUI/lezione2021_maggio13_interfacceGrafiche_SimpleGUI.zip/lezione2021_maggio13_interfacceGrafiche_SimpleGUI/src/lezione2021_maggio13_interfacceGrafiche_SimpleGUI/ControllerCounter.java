package lezione2021_maggio13_interfacceGrafiche_SimpleGUI;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class ControllerCounter {
	private ViewCounter view;
	private ModelCounter model;
	
	public ControllerCounter(ViewCounter view, ModelCounter model) {
		this.view=view;
		this.model=model;
		
		view.inc.addActionListener(e->{
			model.increment();
		//	view.update();
		});
		view.dec.addActionListener(e->{
			model.decrement();
		//	view.update();
		});
		
		view.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {//premo tasto
				// TODO Auto-generated method stub
				if(e.getKeyChar()=='r') {
					model.reset();
				//	view.update();
				}
			}

			@Override
			public void keyPressed(KeyEvent e) {//riceve evento singolo tasto premuto
				// TODO Auto-generated method stub
				
			}

			@Override
			public void keyReleased(KeyEvent e) {//rilascio tasto
				// TODO Auto-generated method stub
				
			}
			
		});
	}
}
