package lezione2021_maggio13_interfacceGrafiche_SimpleGUI;

import static org.junit.Assert.*;


class TestCounter {

	@Test
	void test() {
			ModelCounter c= new ModelCounter();
			assertEquals(0,c.getValore());
			c.increment();
			assertEquals(1,c.getValore());
	}

	public void testView() {
		
		ModelCounter cnt=new ModelCounter();
		ViewCounter view=new ViewCounter(cnt);
		ControllerCounter ctrl=new ControllerCounter(view,cnt);
		
		assertEquals("0",view.val.getText());
		view.inc.doClick();
		Thread.sleep(500);
		assertEquals("1",view.val.getText());
		view.dispose();
	}
}
