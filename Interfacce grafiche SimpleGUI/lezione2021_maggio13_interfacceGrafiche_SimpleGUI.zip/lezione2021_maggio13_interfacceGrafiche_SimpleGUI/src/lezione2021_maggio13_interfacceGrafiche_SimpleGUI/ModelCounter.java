package lezione2021_maggio13_interfacceGrafiche_SimpleGUI;

import java.util.LinkedList;
import java.util.List;

public class ModelCounter {
	private int valore;
	private List<ModelListener> listeners=new LinkedList<>();
	
	public void setModelChangeListener(ModelListener l) {
		listeners.add(l);
	}
	public int getValore() {return valore;}
	public void increment() {
		valore++; 
		listeners.forEach(l->l.modelChanged());
		}
	public void decrement() {if(valore>0) {
		valore--;
		listeners.forEach(l->l.modelChanged());
	}}
	public void reset() {
		if(valore!=0) {
		valore=0; 
	listeners.forEach(l->l.modelChanged());}}
}
