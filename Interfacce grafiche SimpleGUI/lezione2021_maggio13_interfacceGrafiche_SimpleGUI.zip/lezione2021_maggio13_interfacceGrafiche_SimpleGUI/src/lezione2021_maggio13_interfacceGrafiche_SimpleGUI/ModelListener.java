package lezione2021_maggio13_interfacceGrafiche_SimpleGUI;

public interface ModelListener {
	void modelChanged();

}
