package lezione2021_maggio13_interfacceGrafiche_SimpleGUI;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class SimpleFrame extends JFrame{

	public SimpleFrame() {//costruttore
		setSize(800,600);//pixel
		setTitle("Esempio finestra");
		
		JLabel l=new JLabel("Nome:");
		JTextField t=new JTextField(20);
		JButton b=new JButton("Ok");
		
		setLayout(new FlowLayout());//chiedi a setLayout dove mettere i compoenti. Inzia dall'alto a dx e posiziona gli elem in ordine come se fosse un flusso
		add(l);
		add(t);
		add(b);
		this.repaint();//forza il ridisegno della proposta //forza rinfresco della GUI
		
		
		//jPanel e' un contenitore di elementi
		//gridLayot dispone elementi x griglia
		//gridBadLayot ho righe e colonne con dim diversee
	    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	    setVisible(true);
	}
}
