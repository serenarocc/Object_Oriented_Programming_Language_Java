package lezione2021_maggio13_interfacceGrafiche_SimpleGUI;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ViewCounter2 extends JFrame {
	private ModelCounter model;
	JLabel val=new JLabel("?");
	
	
	public ViewCounter2(ModelCounter m) {//costruttore
		this.model=m;
		
		setSize(300,300);
		//setLayout(new FlowLayout());
		setLayout(new BorderLayout());//nord sud 
		val.setHorizontalAlignment(JLabel.CENTER);
	
		add(val,BorderLayout.CENTER);
		
		update();
		
		model.setModelChangeListener(()->{
			update();
		});
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
	}
	
	
	public void update() {
		int valore=model.getValore();
		val.setText(String.valueOf(valore));
	}
}
