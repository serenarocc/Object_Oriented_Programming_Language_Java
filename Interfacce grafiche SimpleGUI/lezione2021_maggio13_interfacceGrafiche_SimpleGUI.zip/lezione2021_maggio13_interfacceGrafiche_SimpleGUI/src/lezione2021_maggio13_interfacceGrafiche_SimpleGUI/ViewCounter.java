package lezione2021_maggio13_interfacceGrafiche_SimpleGUI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ViewCounter extends JFrame{
	private ModelCounter model;
	JButton inc=new JButton("+");
	JButton dec=new JButton("-");
	JLabel val=new JLabel("?");
	public ViewCounter(ModelCounter m) {//costruttore
		this.model=m;
		
		setSize(300,300);
		//setLayout(new FlowLayout());
		setLayout(new BorderLayout());//nord sud 
		val.setHorizontalAlignment(JLabel.CENTER);
		add(inc,BorderLayout.NORTH);
		add(dec,BorderLayout.SOUTH);
		add(val,BorderLayout.CENTER);
		
		update();
		
		model.setModelChangeListener(()->{
			update();
		});
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
	}
	
	ExecutorService runner =Executors.newFixedThreadPool(2);
	public void update() {
		runner.submit(()->{
				int valore=model.getValore();
				val.setText(String.valueOf(valore));
		});
	
	}

}
