package lezione2021_maggio13_interfacceGrafiche_SimpleGUI;

public class AppCounter {

	public static void main(String[] args) {
		
		ModelCounter cnt=new ModelCounter();
		ViewCounter view=new ViewCounter(cnt);
		ViewCounter2 view2=new ViewCounter2(cnt);
		
		ControllerCounter ctrl=new ControllerCounter(view,cnt);
	}
}
