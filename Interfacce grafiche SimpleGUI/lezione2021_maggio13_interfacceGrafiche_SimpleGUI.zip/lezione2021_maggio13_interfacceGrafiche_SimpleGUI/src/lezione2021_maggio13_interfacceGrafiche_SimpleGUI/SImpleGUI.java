package lezione2021_maggio13_interfacceGrafiche_SimpleGUI;

import javax.swing.JFrame;

public class SImpleGUI {

	public static void main(String[] args) {
		// contenitore=finestra
//		JFrame f=new JFrame();//nuova finestra
//		f.setVisible(true);//cosi' la finestra viene visualizzata -->piccolino con 3 tasti
//		
//		f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//rilascia la finestra chiusa e se non ci sono altre finstre attive termina l'applicazione
//	    
		
		SimpleFrame f=new SimpleFrame();
	}

}
