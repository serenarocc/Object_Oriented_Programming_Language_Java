package clinic;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

class Doctor extends Patient {
	private final int id;
	private final String specialization;
	
	private final List<Patient> patients=new LinkedList<>();
	
	public Doctor(String first, String last, String ssn, int id, String specialization) {
		super(first, last, ssn);
		this.id = id;
		this.specialization = specialization;
	}

	public int getId() {
		return id;//ritorna id
	}

	public String getSpecialization() {
		return specialization;//ritorna specializzazione
	}

	public Collection<Patient> getPatients(){//?????????
		Collections.sort( patients);
		return patients;
	}
	
	@Override
	public String toString() {
		return super.toString() + "["+id+"]:"+specialization;
	}

	 void removeMe(Patient person) {
		// TODO Auto-generated method stub
		patients.remove(person);
	}

	void addPatient(Patient p) {
		// TODO Auto-generated method stub
		patients.add(p);//aggiunge il paziente alla lista
	}
	boolean isIdle() {
		//dice se il dottore ha lista di pazienti nulla
		return patients.isEmpty();//ritorna vero se la lista e' vuota(non contiene elementi)
	}
	
	int numPatients() {
		return patients.size();//ritorna il numero di elementi nella lista
	}
	
}
