package it.polito.tvseriesdb;

public class Episode {
	String episodeTitle;
	
	public Episode( String episodeTitle) {
		this.episodeTitle = episodeTitle;
	}
}
