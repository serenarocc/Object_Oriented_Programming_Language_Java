package it.polito.tvseriesdb;
import java.util.*;

public class Actor {
	public String name;
	public String surname;
	public String nationality;
	
	
	public Actor (String name, String surname, String nationality) {
		this.name=name;
		this.surname=surname;
		this.nationality=nationality;
	}
	
	
}
