package it.polito.ski;

public class Slope {
	String name;//nome pista
	String difficulty;
	String lift;//impianto da cui parte
	
	
	public Slope(String name, String difficulty, String lift) {
		super();
		this.name = name;
		this.difficulty = difficulty;
		this.lift = lift;
	}


	public String getName() {
		return name;
	}


	public String getDifficulty() {
		return difficulty;
	}


	public String getLift() {
		return lift;
	}
	
	
	
}
