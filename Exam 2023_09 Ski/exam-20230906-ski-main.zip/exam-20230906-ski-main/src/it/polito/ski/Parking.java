package it.polito.ski;

import java.util.LinkedList;

public class Parking {
	String name;
	int slots;
	LinkedList<String> impianti=new LinkedList<String>();
	
	
	public Parking(String name, int slots) {
		super();
		this.name = name;
		this.slots = slots;
	}
	public String getName() {
		return name;
	}
	public int getSlots() {
		return slots;
	}
	
}
