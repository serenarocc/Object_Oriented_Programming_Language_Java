package it.polito.ski;

public class Lift {
	String name;
	String typeCode;
	
	
	public Lift(String name, String typeCode) {
		super();
		this.name = name;
		this.typeCode = typeCode;
	}
	
	
	
	
	public String getName() {
		return name;
	}
	public String getTypeCode() {
		return typeCode;
	}
	
}
