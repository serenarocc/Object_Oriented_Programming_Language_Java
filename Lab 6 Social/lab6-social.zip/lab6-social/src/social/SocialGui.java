//mod
package social;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.Serial;
import java.util.Collection;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;


public class SocialGui extends JFrame {
	@Serial
	private static final long serialVersionUID = 1L;

	private static final int H=300;//altezza
	private static final int W=400;//larghezza
	// The following components are declared public
	// in order to allow testing the user interface
	public JLabel l1=new JLabel("ID:");//def nome etichetta
	/**
	 * The code of the person to log in
	 */
	public JTextField id=new JTextField("",10) ;//def dim spazio
	
	/**
	 * The button to perform login
	 */
	public JButton login=new JButton("Login") ;//def nome pulsante
	
	/**
	 * The label that shall contain the info
	 * of the logged in person 
	 */
	public JLabel name =new JLabel("<user name>");//def nome etichetta
	
	/**
	 * The list of friends of the person
	 * that is logged in
	 */
	public JList<String> friends=new JList<>() ;//def lista
	private Social model;
	
	
	

	public SocialGui(Social m){//costruttore
		this.model=m;
		setTitle("MyFacebook");
		setSize(W,H);
		//getDefaultToolkit= della classe toolkit prendo il toolkit di default
		Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();//getScreenSize= prende dim schermo
		setLocation(screen.width/2-W/2,screen.height/2-H/2);//lo posiziona a centro schermo
		
		Image icon=new ImageIcon(SocialGui.class.getResource("PoliLogoBlu.png")).getImage();//???
		setIconImage(icon);//icona log alto sx
		//Application.getApllication().setDockIconImage(icon);
		
		setLayout(new BorderLayout());//layout con bordi
		
		JPanel upper=new JPanel();
		upper.setLayout(new FlowLayout());//dispone a modo di stream le cose
		upper.add(l1);
		upper.add(id);
		upper.add(login);
		add(upper,BorderLayout.NORTH);
		
		
		JPanel lower=new JPanel();
		lower.setLayout(new BorderLayout());//bordo decorativo
		
		JPanel infopanel = new JPanel();
		infopanel.add(name);
		lower.add(infopanel,BorderLayout.NORTH);

		JPanel details = new JPanel();
		details.setLayout(new GridLayout(1,1,5,5));
		
		details.add(friends);
		//details.add(groups);
		lower.add(details,BorderLayout.CENTER);
	
		add(lower,BorderLayout.CENTER);
		lower.setBorder(new LineBorder(Color.DARK_GRAY));
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
		
		friends.setListData(new String[]{"friends","..."});
		//groups.setListData(new String[]{"groups    ","..."});
		
		login.addActionListener(event -> {//faccio azione premere
			if(event.getActionCommand().equals("Login")){
				doLogin();
			}
		});
		id.addKeyListener(new KeyAdapter(){//ascolto pressione pulsante 
			public void keyReleased(KeyEvent event) {
				if(event.getKeyCode() == KeyEvent.VK_ENTER){
					doLogin();
				}
			}
		});
		//inserisci un nuovo listener . ascolto un nuovo tipo evento quando viene rilasciato tasto enter della tastiera fai login
		
	}


	private void doLogin() {
		try {
			String code = id.getText();
			String person = model.getPerson(code);
			name.setText(person);
			
			Collection<String> listOfFriends = model.listOfFriends(code);
			friends.setListData(listOfFriends.toArray(new String[listOfFriends.size()]));
		} catch (NoSuchCodeException e) {
			JOptionPane.showMessageDialog(this, "Invalid user code","Error",JOptionPane.ERROR_MESSAGE);
		}
	}
	


}
