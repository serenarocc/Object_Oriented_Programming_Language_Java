package social;
//7
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


public class Social {
	private final HashMap<String,Person> people=new HashMap<>();
	private final HashMap<String,Group> groups=new HashMap<>();
	
	/**
	 * Creates a new account for a person
	 * 
	 * @param code	nickname of the account
	 * @param name	first name
	 * @param surname last name
	 * @throws PersonExistsException in case of duplicate code
	 */
	public void addPerson(String code, String name, String surname) throws PersonExistsException {
		Person p=new Person(code, name, surname);
		 if(people.containsKey(code)) {//controllo se codice univoco e' gia' associato a un account
			 //containsKey=restituisce  true se questa mappa contiene una mappatura x la chiave specificata
			 throw new PersonExistsException();
		 }
		 people.put(code, p);
	}
	
	public void test() {
		
	}

	/**
	 * Retrieves information about the person given their account code.
	 * The info consists in name and surname of the person, in order, separated by blanks.
	 * 
	 * @param code account code
	 * @return the information of the person
	 * @throws NoSuchCodeException
	 */
	public String getPerson(String code) throws NoSuchCodeException {
		Person p=people.get(code);
		if(p==null) {
			throw new NoSuchCodeException();
		}
		return p.toString();
	}

	/**
	 * Define a friendship relationship between to persons given their codes.
	 * 
	 * Friendship is bidirectional: if person A is friend of a person B, that means that person B is a friend of a person A.
	 * 
	 * @param codePerson1	first person code
	 * @param codePerson2	second person code
	 * @throws NoSuchCodeException in case either code does not exist
	 */
	public void addFriendship(String codePerson1, String codePerson2) throws NoSuchCodeException {
		Person p1=people.get(codePerson1);
		Person p2=people.get(codePerson2);
		if(p1==null ||p2==null) throw new NoSuchCodeException();
		p1.addFriend(codePerson2);
		p2.addFriend(codePerson1);
	}

	/**
	 * Retrieve the collection of their friends given the code of a person.
	 * 
	 * 
	 * @param codePerson code of the person
	 * @return the list of person codes
	 * @throws NoSuchCodeException in case the code does not exist
	 */
	public Collection<String> listOfFriends(String codePerson) throws NoSuchCodeException {
		if(people.containsKey(codePerson)) {
			if(people.get(codePerson).getFriends().size()==0)
				return new LinkedList<>();
			else
				return people.get(codePerson).getFriends();
		}else {
			throw new NoSuchCodeException();
		}
	}
	
	
	
	private final static Collection<String> emptyList=new LinkedList<>();


	/**
	 * Retrieves the collection of the code of the friends of the friends
	 * of the person whose code is given, i.e. friends of the second level.
	 * 
	 * 
	 * @param codePerson code of the person
	 * @return collections of codes of second level friends
	 * @throws NoSuchCodeException in case the code does not exist
	 */
	//metodo e' di tipo collection di String xke con getFriends ritorno un HashSet di tipo stringa
	public Collection<String> friendsOfFriends(String codePerson) throws NoSuchCodeException {
		Person p1= people.get(codePerson);//ricavo la persona che ha quel codice
		if(p1==null) throw new NoSuchCodeException();
		
		return p1.getFriends().stream() //di quella persona,recupero l'elenco dei codici dei suoi amici e ci faccio lo stream
				.map(people::get)//di tutte gli amici recupero le persone grazie ai codici trovati prima
				.map(Person::getFriends)//recupero gli amici dei propri amici--<sono di nuovo dei codici
				.flatMap(Collection::stream)//di questi amici dei propri amici faccio lo stream
				.filter(p->!p.equals(codePerson))//di questo elenco tolgo la persona con codePerson
				.collect(Collectors.toList());//accumolo gli elementi in una list(essendo che il metodo vuole come return una collection di string)
		
	}

	/**
	 * Retrieves the collection of the code of the friends of the friends
	 * of the person whose code is given, i.e. friends of the second level.
	 * The result has no duplicates.
	 * 
	 * 
	 * @param codePerson code of the person
	 * @return collections of codes of second level friends
	 * @throws NoSuchCodeException in case the code does not exist
	 */
	//metodo e' di tipo collection di String xke con getFriends ritorno un HashSet di tipo stringa
	public Collection<String> friendsOfFriendsNoRepetition(String codePerson) throws NoSuchCodeException {
		Person p1= people.get(codePerson);//ricavo la persona che ha quel codice
		if(p1==null) throw new NoSuchCodeException();
		
		return p1.getFriends().stream() //di quella persona,recupero l'elenco dei suoi amici e ci faccio lo stream
				.map(people::get)//??
				.map(Person::getFriends)//recupero gli amici dei propri amici
				.flatMap(Collection::stream)//di questi amici dei propri amici faccio lo stream
				.filter(p->!p.equals(codePerson))//di questo elenco tolgo la persona con codePerson
				.collect(Collectors.toSet());//restituisce una raccolta che NON contiene elementi duplicati
	}

	/**
	 * Creates a new group with the given name
	 * 
	 * @param groupName name of the group
	 */
	public void addGroup(String groupName) {
		Group g1=new Group(groupName);
		groups.put(groupName, g1);
	}

	/**
	 * Retrieves the list of groups.
	 * 
	 * @return the collection of group names
	 */
	//metodo ritorna un tipo collezioni groups(HashMap) e di lui si restituice la visita delle chiavi
	public Collection<String> listOfGroups() {
		if(groups.size()==0)
			return emptyList;
		return groups.keySet();//Restituisce:una vista impostata delle chiavi contenute in questa mappa
	}

	/**
	 * Add a person to a group
	 * 
	 * @param codePerson person code
	 * @param groupName  name of the group
	 * @throws NoSuchCodeException in case the code or group name do not exist
	 */
	public void addPersonToGroup(String codePerson, String groupName) throws NoSuchCodeException {
		Group g=groups.get(groupName);
		Person p=people.get(codePerson);
		if(g==null || p==null) {
			throw new NoSuchCodeException();
		}
		g.addPerson(codePerson);
		p.addGroup(groupName);
	}

	/**
	 * Retrieves the list of people on a group
	 * 
	 * @param groupName name of the group
	 * @return collection of person codes
	 */
	//e' di tipo Collection String xke con getMembers ritorna un HashSet di tipo stringa
	public Collection<String> listOfPeopleInGroup(String groupName) {
		Group g=groups.get(groupName);
		if(g==null) return null;
		return g.getMembers();
	}

	/**
	 * Retrieves the code of the person having the largest
	 * group of friends
	 * 
	 * @return the code of the person
	 */
	public String personWithLargestNumberOfFriends() { //????
		return people.values().stream() //java.util.HashMap.values()-> viene usato x creare una raccolta di valori della mappa
				//stream dei valori di tutte le persone della HashMap people
				.max(Comparator.comparing(p->p.getFriends().size()))//li ordino in base alla dimensione 
				//del num di amici e di loro prendo solo la persona con il numero di amici maggiori
				.map(Person::getCode).orElse("<none>");//di questa persona prendo il suo codice
		//Comparator.comparing()= metodo che utilizzera' il campo specificato come chiave di ordinamento
	}
	
	//???????????????????
	private interface ExcFun<T,U,E extends Exception> { U apply(T t) throws E; }
	private static <T,U> Function<T,U> hideException(ExcFun<T,U,?> f){
		return x -> {
			try {
				return f.apply(x);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		};
	}
	

	/**
	 * Find the code of the person with largest number
	 * of second level friends
	 * 
	 * @return the code of the person
	 */
	public String personWithMostFriendsOfFriends() {//???
		return people.values().stream()//stream dei valori di tutte le persone della HashMap people
				.max(Comparator.comparing(hideException(p->friendsOfFriends(p.getCode()).size())))
				.map(Person::getCode).orElse("<none>");
		//Comparator.comparing()= metodo che utilizzera' il campo specificato come chiave di ordinamento
	}

	/**
	 * Find the name of group with the largest number of members
	 * 
	 * @return the name of the group
	 */
	public String largestGroup() {
		return groups.values().stream()//stream dei valori di tutti i groups della HashMap people
				.max(Comparator.comparing(g->g.getMembers().size()))//li ordino in base alla dimensione del gruppo
				//Dell'ordine prendo solo il gruppo con la dimensione massima
				.map(Group::getName).orElse("<none>");//del gruppo ne ritorno il nome
		//Comparator.comparing()= metodo che utilizzera' il campo specificato come chiave di ordinamento
	}

	/**
	 * Find the code of the person that is member of
	 * the largest number of groups
	 * 
	 * @return the code of the person
	 */
	public String personInLargestNumberOfGroups() {
		return null;
	}
}