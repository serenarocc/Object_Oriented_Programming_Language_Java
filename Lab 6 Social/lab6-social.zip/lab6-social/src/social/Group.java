package social;

import java.util.Collection;
import java.util.HashSet;

public class Group {
	private final String name;
	
	private final HashSet<String> members=new HashSet<>();//HASHSET =raccolta di elementi in cui ogni elemento è unico
	//non uso HASHMAP xke non ho una condizione chiave/valore.
	//Non uso LINKEDLIST o ARRAYLIST xke qui gli elementi si posssono ripetere
	
	
	public Group(String groupName) {
		this.name = groupName;
	}
	
	public void addPerson(String codePerson) {
		members.add(codePerson);
	}
	public Collection<String> getMembers(){ //e' di tipo collezioni di stringhe xke deve ritornare HashSet
		return members;
	}

	public String getName() {
		return name;
	}
 }
