package social;

import java.util.HashSet;
import java.util.Collection;

public class Person {
	private final String code;
	private final String name;
	private final String surname;
	
	private final HashSet<String> friends= new HashSet<>();//HASHSET =raccolta di elementi in cui ogni elemento è unico
	//contiene solo i codici degli amici
	private final HashSet<String> groups= new HashSet<>();
	//non uso HASHMAP xke non ho una condizione chiave/valore.
	//Non uso LINKEDLIST o ARRAYLIST xke qui gli elementi si posssono ripetere
	
	
	
	public Person(String code, String name, String surname) {
		this.code = code;
		this.name = name;
		this.surname = surname;
	}

	@Override
	public String toString() {
		return "Person [code=" + code + ", name=" + name + ", surname=" + surname + "]";
	}
	
	public void addFriend(String code) {
		friends.add(code);
	}
	
	public Collection<String> getFriends(){ //e' di tipo collezioni di stringhe xke deve ritornare HashSet
		return friends;
	}
	
	public Collection<String> getGroups(){ //e' di tipo collezioni di stringhe xke deve ritornare HashSet
		return groups;
	}
	
	public void addGroup(String groupName) {
		groups.add(groupName);
	}

	public String getCode() {
		return code;
	}
}
