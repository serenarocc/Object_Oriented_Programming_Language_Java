import org.junit.Test;

public class SimpleTest {
	
	@Test
	public void testAll(){
		ExampleApp.main(null);
    }
}
