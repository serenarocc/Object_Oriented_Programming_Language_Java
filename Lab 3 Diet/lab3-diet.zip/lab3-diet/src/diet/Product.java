package diet;

 class Product implements NutritionalElement{
	private final String name;
	private final double calories;
	private final double proteins;
	private final double carbs;
	private final double fat;
	
	//source->generate constructor con field
	public Product(String name, double calories, double proteins, double carbs, double fat) {
		//super(); tanto non e' ereditata
		this.name = name;
		this.calories = calories;
		this.proteins = proteins;
		this.carbs = carbs;
		this.fat = fat;
	}
	
	
//source->generate getter
	public String getName() {
		return name;
	}

	public double getCalories() {
		return calories;
	}

	public double getProteins() {
		return proteins;
	}

	public double getCarbs() {
		return carbs;
	}

	public double getFat() {
		return fat;
	}
	public boolean per100g() {
		return false;//R2
	}
	
}
