package esame2022_luglio12_papers;

import java.util.*;

public class Author {

	String name;
	Double impactFactor=0.0;
	TreeSet<String> papers=new TreeSet<String>();
	
	
	public Author(String name) {
		this.name = name;
	}
	
	int getSizePapers() {
		return papers.size();
	}
	
	double getImpactFactor() {
		return impactFactor;
	}
	
	String getName() {
		return name;
	}
}
