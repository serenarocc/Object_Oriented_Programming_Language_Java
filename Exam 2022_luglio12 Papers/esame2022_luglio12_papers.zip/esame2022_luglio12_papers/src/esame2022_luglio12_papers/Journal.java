package esame2022_luglio12_papers;
import java.util.*;
public class Journal {
	String jName;
	double impactF;
	ArrayList<String> papers=new ArrayList<String>();
	
	public Journal(String jName, double impactF) {
		super();
		this.jName = jName;
		this.impactF = impactF;
	}

	public String getjName() {
		return jName;
	}
	public double getImpactF() {
		return impactF;
	}
	ArrayList<String> getPapers(){
		return papers;
	}
	
	int getNofPapers() {
		return papers.size();
		}

}
