package esame2022_luglio12_papers;
import java.util.*;
import static java.util.Comparator.*;
import static java.util.stream.Collectors.*;

public class Journals {
TreeMap<String,Journal> jMap=new TreeMap<>();
TreeMap<String,Author> authors=new TreeMap<>();
	//R1 
	/**
	 * inserts a new journal with name and impact factor. 
	 * 
	 * @param name	name of the journal
	 * @param impactFactor relative impact factor
	 * @return  the number of characters of the name
	 * @throws JException if the journal (represented by its name) already exists
	 */
/* inserisce una nuova rivista con nome e fattore di impatto. Genera un'eccezione se la rivista
 *  (rappresentato dal nome) esiste già. Il risultato é il numero di caratteri del nome.*/
	public int addJournal (String name, double impactFactor) throws JException {
		if(jMap.containsKey(name)) throw new JException("rivista esiste gia'");
		Journal j=new Journal(name,impactFactor);
		jMap.put(name, j);
		return name.length();
	}

	/**
	 * retrieves the impact factor of the journal indicated by the name
	 * 
	 * @param name the journal name
	 * @return the journal IF
	 * @throws JException if the journal does not exist
	 */
/* fornisce il fattore di impatto della rivista indicata dal nome. 
 * Genera un'eccezione se la rivista non esiste.*/
	public double getImpactFactor (String name) throws JException {
		Journal j= jMap.get(name);
		if(j==null) throw new JException("journal non conosciuto'");
		return j.impactF;
	}

	/**
	 * groups journal names by increasing impact factors. 
	 * Journal names are listed in alphabetical order
	 * 
	 * @return the map of IF to journal
	 */
/* raggruppa i nomi delle riviste in base ai fattori di
 *  impatto crescenti. I nomi delle riviste sono elencati in ordine alfabetico.*/
	public SortedMap<Double, List<String>> groupJournalsByImpactFactor () {
		return jMap.values().stream()
				.sorted(comparing(Journal::getjName))//ordine alfabetico nomi delle riviste
				.collect(groupingBy(Journal::getImpactF,//in base ai fattori di carico--> key della treeMap( vedere i dati risultanti di ritorno attesi dal metodo)
									TreeMap::new,
									mapping(Journal::getjName,//ragruppo i nomi delle riviste-->lista value della treeMap( vedere i dati risultanti di ritorno attesi dal metodo)
											toList())));
	}

	//R2
	/**
	 * adds authors. 
	 * Duplicated authors are ignored.
	 * 
	 * @param authorNames names of authors to be added
	 * @return the number of authors entered so far
	 */
/* aggiunge autori. Autori duplicati sono ignorati. 
 * Il risultato é il numero di autori inserito finora.*/
	public int registerAuthors (String... authorNames) {
		for(String name:authorNames) {
			authors.computeIfAbsent(name, (a)->new Author(a));//evita duplicati
		}
		return authors.keySet().size();
	}
	
	/**
	 * adds a paper to a journal. 
	 * The journal is indicated by its name; 
	 * the paper has a title that must be unique in the specified journal,
	 * the paper can have one or more authors.
	 * 
	 * @param journalName
	 * @param paperTitle
	 * @param authorNames
	 * @return the journal name followed by ":" and the paper title.
	 * @throws JException if the journal does not exist or the title is not unique within the journal or not all authors have been registered
	 */
/*aggiunge un articolo a una rivista. La rivista é indicata tramite il nome; il metodo scatena 
 * un'eccezione se la rivista non esiste. L'articolo ha un titolo che deve essere unico nella
 *  rivista specificata, altrimenti deve essere generata un'eccezione. L'articolo può avere
 *   più autori: se non tutti gli autori sono stati registrati viene generata un'eccezione. 
 *   Il risultato é il nome della rivista seguito da ":" e dal titolo dell'articolo.*/
	public String addPaper (String journalName, String paperTitle, String... authorNames) throws JException {
		
		Journal j1=jMap.get(journalName);//il metodo scatena un'eccezione se la rivista non esiste
		if(j1==null) throw new JException("journal non conosciuto'");
		
		
		ArrayList<String> authorsList=new ArrayList<String>(Arrays.asList(authorNames));//???
		
		if(!authors.keySet().containsAll(authorsList)){//????
			throw new JException("eccezione NON SCRITTA'");
		}
		if(j1.papers.contains(paperTitle)) {
			//L'articolo ha un titolo che deve essere unico nella rivista specificata, altrimenti deve essere generata un'eccezione. 
			throw new JException("dulicato dell'articolo nel giornale'");
		}
		//add paper to journal
		j1.papers.add(paperTitle);
		
		
		for(String nameA: authorNames) {
			Author au=authors.get(nameA);
			au.papers.add(paperTitle);
			au.impactFactor=au.impactFactor+j1.impactF;
		}
		
		return journalName + ":" +paperTitle;
	}
	
	/**
	 * gives the number of papers for each journal. 
	 * Journals are sorted alphabetically. 
	 * Journals without papers are ignored.
	 * 
	 * @return the map journal to count of papers
	 */
/* fornisce il numero di articoli per ogni rivista. Le rivste sono ordinate alfabeticamente.
 *  Le riviste senza articoli sono ignorate.*/
	public SortedMap<String, Integer> giveNumberOfPapersByJournal () { //serve toMap
		return jMap.values().stream()
				.filter(j -> j.papers.size() > 0)//Le riviste senza articoli sono ignorate.
				.collect(toMap(Journal::getjName,//per ogni rivista:  L1
							   Journal::getNofPapers, //fornisce il numero di articoli: L2
							   (l1, l2) -> l1,
							   TreeMap::new));	//costruisco treeMap con chiave L1 e valori L2   ?????????????????????
	}
	
	//R3
	/**
	 * gives the impact factor for the author indicated.
	 * The impact factor of an author is obtained by adding 
	 * the impact factors of his/her papers. 
	 * The impact factor of a paper is equal to that of the 
	 * journal containing the paper.
	 * If the author has no papers the result is 0.0.
	 *
	 * @param authorName
	 * @return author impact factor
	 * @throws JException if the author has not been registered
	 */
/* fornisce il fattore di impatto per l'autore indicato. Il fattore di impatto di 
 * un autore si ottiene sommando i fattori di impatto dei suoi articoli.
 * Il fattore di impatto di un articolo é uguale a quello della rivista che lo contiene. 
 * Il metodo genera un'eccezione se l'autore non é stato registrato.
 * Se l'autore non ha articoli il risultato é 0.0.*/
	public double getAuthorImpactFactor (String authorName) throws JException {
		
		if(!authors.containsKey(authorName))throw new JException("autore non registrato");
		
		return authors.get(authorName).impactFactor;
	}
	
	/**
	 * groups authors (in alphabetical order) by increasing impact factors.
	 * Authors without papers are ignored.
	 * 
	 * @return the map IF to author list
	 */
/* raggruppa gli autori (in ordine alfabetico) per fattore di impatto crescente. 
 * Gli autori senza articoli vengono ignorati.*/
	public SortedMap<Double, List<String>> getImpactFactorsByAuthors () {
		return authors.values().stream()
				.filter(a->a.getSizePapers()>0)//Gli autori senza articoli vengono ignorati.
				.collect(groupingBy(Author::getImpactFactor,//(in base) per fattore di impatto crescente. 
									TreeMap::new,
									mapping(Author::getName,//raggruppa gli autori (in ordine alfabetico) 
											toList())));
	
	}
	
	
	//R4 
	/**
	 * gives the number of papers by author; 
	 * authors are sorted alphabetically. 
	 * Authors without papers are ignored.
	 * 
	 * @return
	 */
/* fornisce il numero di articoli per autore; gli autori sono ordinati in ordine alfabetico. 
 * Gli autori senza articoli vengono ignorati.*/
	public SortedMap<String, Integer> getNumberOfPapersByAuthor() {
		return authors.values().stream()
				.filter(a->a.getSizePapers()>0)//Gli autori senza articoli vengono ignorati.
				.collect(toMap(Author::getName,//per autore: L1
							   Author::getSizePapers,//fornisce il numero di articoli:  L2
						       (l1,l2)->l1,
						       TreeMap::new));//costruisco treeMap con chiave L1 e valori L2  //???????????
	}
	
	/**
	 * gives the name of the journal having the largest number of papers.
	 * If the largest number of papers is common to two or more journals 
	 * the result is the name of the journal which is the first in 
	 * alphabetical order.
	 * 
	 * @return journal with more papers
	 */
/* fornisce il nome della rivista con il maggior numero di articoli. 
 * Se il maggior numero di articoli é comune a due o più riviste il risultato é il nome
 *  della rivista che é la prima in ordine alfabetico.*/
	public String getJournalWithTheLargestNumberOfPapers() {
		ArrayList<Journal> jList = new ArrayList<>(jMap.values());//???
		Collections.sort(jList, comparing(Journal::getNofPapers, 
				reverseOrder()).thenComparing(Journal::getjName));
		Journal jl = jList.get(0);
		return jl.getjName() + ":" + jl.getNofPapers();
	}
}
