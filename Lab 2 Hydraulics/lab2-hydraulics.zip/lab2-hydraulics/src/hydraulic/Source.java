//mod3
package hydraulic;

/**
 * Represents a source of water, i.e. the initial element for the simulation.
 *
 * Lo status of the source is defined through the method
 * {@link #setFlow(double) setFlow()}.
 */
public class Source extends Element {
	private double flow;
	private double maxFlow;

	/**
	 * constructor
	 * @param name name of the source element
	 */
	public Source(String name) {
		super(name);
	}

	/**
	 * Define the flow of the source to be used during the simulation
	 *
	 * @param flow flow of the source (in cubic meters per hour)
	 */
	public void setFlow(double flow){
		this.flow=flow;
		this.maxFlow=flow;
	}
	
	
	@Override
	protected StringBuffer layout(String pad) {
		StringBuffer res = new StringBuffer();
		res.append("[").append(getName()).append("]Source -> ");
		res.append( getOutput()==null?"*":getOutput().layout(blanks(res.length())) );
		return res;
	}
	
	@Override
	public void setMaxFlow(double maxFlow) {
		return;
	}
	
	
	
	
	
	
	protected void simulate(double inFlow, SimulationObserver observer, boolean enableMaxFlowChecks) {
		observer.notifyFlow("Source",getName(),SimulationObserver.NO_FLOW, flow);
		if(enableMaxFlowChecks && inFlow>maxFlow)
			observer.notifyFlowError(this.getClass().getName(), getName(), inFlow, maxFlow);
		getOutput().simulate(flow,observer,enableMaxFlowChecks);
		
		
		
		
		
		
	//	observer.notifyFlow("Source",getName(),SimulationObserver.NO_FLOW, flow);
		//getOutput().simulate(flow,observer);	
	}
}
