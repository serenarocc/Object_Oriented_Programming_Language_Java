//mod3
package hydraulic;

/**
 * Represents the sink, i.e. the terminal element of a system
 *
 */
public class Sink extends Element {

	/**
	 * Constructor
	 * @param name name of the sink element
	 */
	public Sink(String name) {
		super(name);
	}
	@Override
	public void connect(Element elem){
		// no effect!
	}

	@Override
	protected StringBuffer layout(String pad) {
		StringBuffer res = new StringBuffer();
		res.append("[").append(getName()).append("]Sink");
		return res;
	}
	@Override
	protected void simulate(double inFlow, SimulationObserver observer, boolean enableMaxFlowChecks) {
		if(enableMaxFlowChecks && inFlow>maxFlow)
			observer.notifyFlowError(this.getClass().getName(), getName(), inFlow, maxFlow);
		observer.notifyFlow("Sink", getName(), inFlow, SimulationObserver.NO_FLOW);
	}
	@Override
	protected void simulate(double inFlow, SimulationObserver observer) {
		// TODO Auto-generated method stub
		
	}
}
